export const blackColor = '#343434';
export const whiteColor = '#fff';
export const bgColor = '#F5F7F9';
export const grayColor = '#7D7D7D';
export const primaryColor = '#4340DA';
export const primaryHoverColor = '#3835ba';
export const dangerColor = '#D93025';
